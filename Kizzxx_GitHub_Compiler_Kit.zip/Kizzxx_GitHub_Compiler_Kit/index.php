<?php
session_start();
$configFile = __DIR__ . '/config.php';
$config = file_exists($configFile) ? require $configFile : null;
$notice = '';
$actionsUrl = '';
function gh_request($method, $url, $token, $data = null) {
  if (!function_exists('curl_init')) throw new Exception('PHP cURL tidak tersedia di hosting.');
  $ch = curl_init($url);
  $headers = ['Accept: application/vnd.github+json','Authorization: Bearer '.$token,'X-GitHub-Api-Version: 2022-11-28','User-Agent: Kizzxx-HTML-to-APK'];
  curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_HTTPHEADER=>$headers,CURLOPT_TIMEOUT=>45]);
  if ($data !== null) { $headers[] = 'Content-Type: application/json'; curl_setopt($ch, CURLOPT_HTTPHEADER, $headers); curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data)); }
  $body = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch); curl_close($ch);
  if ($body === false) throw new Exception('Koneksi GitHub gagal: '.$err);
  if ($code < 200 || $code >= 300) { $j=json_decode($body,true); throw new Exception('GitHub API '.$code.': '.($j['message'] ?? substr($body,0,300))); }
  return $body === '' ? [] : (json_decode($body,true) ?: []);
}
function gh_put_file($cfg, $path, $bytes, $message) {
  $base='https://api.github.com/repos/'.$cfg['github_owner'].'/'.$cfg['github_repo'].'/contents/'.implode('/',array_map('rawurlencode',explode('/',$path)));
  // Nama file upload dibuat unik, jadi tidak perlu membaca SHA file lama.
  $payload=['message'=>$message,'content'=>base64_encode($bytes),'branch'=>$cfg['github_branch']];
  return gh_request('PUT',$base,$cfg['github_token'],$payload);
}
if ($_SERVER['REQUEST_METHOD']==='POST') {
  try {
    if (!$config) throw new Exception('Buat config.php dari config.example.php terlebih dahulu.');
    if (empty($config['github_token']) || $config['github_token']==='ISI_FINE_GRAINED_TOKEN_DI_SINI') throw new Exception('Token GitHub belum diisi di config.php.');
    if (!isset($_FILES['project']) || $_FILES['project']['error']!==UPLOAD_ERR_OK) throw new Exception('Pilih file HTML atau ZIP terlebih dahulu.');
    $f=$_FILES['project']; if ($f['size']>20*1024*1024) throw new Exception('Ukuran maksimum 20 MB.');
    $ext=strtolower(pathinfo($f['name'],PATHINFO_EXTENSION)); if (!in_array($ext,['html','htm','zip'],true)) throw new Exception('Format hanya HTML, HTM, atau ZIP.');
    $app=trim($_POST['app_name'] ?? 'Kizzxx App'); $pkg=trim($_POST['package_name'] ?? 'com.kizzxx.app'); $orientation=$_POST['orientation'] ?? 'portrait'; $splash=$_POST['splash_color'] ?? '#170b27';
    if (!preg_match('/^[A-Za-z][A-Za-z0-9 _.-]{0,39}$/',$app)) throw new Exception('Nama aplikasi tidak valid.');
    if (!preg_match('/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/',$pkg)) throw new Exception('Package name harus seperti com.kizzxx.app.');
    if (!in_array($orientation,['portrait','landscape','sensor'],true)) $orientation='portrait';
    if (!preg_match('/^#[0-9a-fA-F]{6}$/',$splash)) $splash='#170b27';
    $id=date('YmdHis').'-'.bin2hex(random_bytes(3)); $path='input/'.$id.'.'.$ext;
    gh_put_file($config,$path,file_get_contents($f['tmp_name']),'Upload Kizzxx project '.$id);
    $workflow=['ref'=>$config['github_branch'],'inputs'=>['project_path'=>$path,'app_name'=>$app,'package_name'=>$pkg,'orientation'=>$orientation,'splash_color'=>$splash]];
    gh_request('POST','https://api.github.com/repos/'.$config['github_owner'].'/'.$config['github_repo'].'/actions/workflows/build-apk.yml/dispatches',$config['github_token'],$workflow);
    $notice='Project berhasil dikirim ke GitHub Actions. Build Android sedang dimulai.';
    $actionsUrl='https://github.com/'.$config['github_owner'].'/'.$config['github_repo'].'/actions/workflows/build-apk.yml';
  } catch (Throwable $e) { $notice='Gagal: '.$e->getMessage(); }
}
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Kizzxx HTML to APK PRO</title>
<style>
:root{--bg:#090711;--panel:#151020;--line:#352344;--purple:#a855f7;--muted:#a99bb7}*{box-sizing:border-box}body{margin:0;background:radial-gradient(ellipse at 80% 0%,#241333 0,transparent 35%),var(--bg);color:#fff;font:15px Inter,Arial,sans-serif}header{height:72px;padding:0 5%;display:flex;align-items:center;justify-content:space-between;background:#100b19;border-bottom:1px solid var(--line);position:sticky;top:0;z-index:2}.brand{font-weight:900;font-size:21px}.brand span{color:#c084fc}.pill{font-size:11px;color:#d8b4fe;background:#29183a;padding:9px 13px;border-radius:20px}main{max-width:950px;margin:auto;padding:25px 16px}.hero,.card{border:1px solid var(--line);border-radius:17px;background:linear-gradient(145deg,#1b1228,#120e1b);padding:22px;margin-bottom:17px}.hero{background:radial-gradient(ellipse at 90% 0%,#4a2468 0,transparent 50%),#171020}.eyebrow{font-size:11px;letter-spacing:2px;color:#d8b4fe}h1{font-size:29px;margin:12px 0 8px}h2{font-size:17px;margin:0 0 16px}.muted,.help{color:var(--muted);font-size:12px;line-height:1.7}.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}label{display:block;font-size:12px;color:#d6c9df;margin:13px 0 7px}input,select{width:100%;padding:13px;border-radius:10px;border:1px solid #49345b;background:#0c0913;color:#fff}input[type=file]{padding:14px}button,.linkbtn{display:block;text-align:center;width:100%;padding:15px;border:0;border-radius:11px;background:linear-gradient(100deg,#792cff,#bb5cff);color:#fff;font-weight:800;text-decoration:none;margin-top:16px}.notice{padding:14px;border:1px solid #62427a;background:#261a35;border-radius:11px;margin-bottom:17px;font-size:13px;line-height:1.6}.steps{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.step{background:#21182d;border:1px solid #382748;padding:13px;border-radius:10px;font-size:12px}.help{margin-top:14px}footer{text-align:center;color:#766b83;padding:24px;font-size:11px}@media(max-width:600px){.grid{grid-template-columns:1fr}.steps{grid-template-columns:1fr 1fr}h1{font-size:25px}}
</style></head><body><header><div class="brand">KIZZXX <span>DEV.</span></div><div class="pill">● HTML TO APK PRO</div></header><main>
<section class="hero"><div class="eyebrow">ANDROID APPLICATION BUILDER</div><h1>HTML TO APK <span style="color:#c084fc">PRO.</span></h1><p class="muted">Upload project website dan build menjadi APK Android native berbasis WebView melalui GitHub Actions.</p></section>
<?php if($notice): ?><div class="notice"><?=htmlspecialchars($notice)?><?php if($actionsUrl): ?><a class="linkbtn" href="<?=htmlspecialchars($actionsUrl)?>" target="_blank" rel="noopener">BUKA BUILD PROGRESS ↗</a><?php endif; ?></div><?php endif; ?>
<form method="post" enctype="multipart/form-data"><section class="card"><h2>01 — Upload Project</h2><label>File HTML / ZIP (maks. 20 MB)</label><input type="file" name="project" accept=".html,.htm,.zip" required><p class="help">ZIP berisi website-mu (index.html, CSS, JavaScript, gambar, dan aset). HTML tunggal juga didukung.</p></section>
<section class="card"><h2>02 — App Configuration</h2><div class="grid"><div><label>Nama aplikasi</label><input name="app_name" maxlength="40" value="Kizzxx App" required></div><div><label>Package name</label><input name="package_name" value="com.kizzxx.app" pattern="[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+" required></div><div><label>Orientasi layar</label><select name="orientation"><option value="portrait">Portrait</option><option value="landscape">Landscape</option><option value="sensor">Auto rotate</option></select></div><div><label>Warna splash screen</label><input type="color" name="splash_color" value="#170b27"></div></div></section>
<section class="card"><h2>03 — Build Android APK</h2><div class="steps"><div class="step">📦 Upload HTML / ZIP</div><div class="step">📱 Android WebView</div><div class="step">⚙️ GitHub Actions Build</div></div><button type="submit">🚀 UPLOAD & BUILD APK</button><p class="help">Setelah dikirim, buka halaman Actions untuk melihat status dan mengunduh APK dari bagian Artifacts jika build sukses.</p></section></form></main><footer>KIZZXX DEV © 2026 · HTML TO APK PRO</footer></body></html>
