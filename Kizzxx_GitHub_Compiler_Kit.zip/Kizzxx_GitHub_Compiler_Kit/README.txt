KIZZXX HTML TO APK — GITHUB ACTIONS COMPILER KIT

PENTING: Ini compiler cloud berbasis GitHub Actions. Hosting InfinityFree hanya menjalankan dashboard PHP. APK debug akan muncul sebagai Artifact di GitHub Actions; ini bukan Play Store release/signing setup.

A. BUAT REPOSITORY
1. GitHub > New repository > nama: kizzxx-html-to-apk > Public atau Private > Create.
2. Upload seluruh ISI folder kit ini ke root repository, pastikan .github/workflows/build-apk.yml ikut ter-upload.
3. Pastikan branch bernama main.

B. BUAT TOKEN GITHUB
1. GitHub Settings > Developer settings > Personal access tokens > Fine-grained tokens.
2. Generate token untuk repository kizzxx-html-to-apk saja.
3. Repository permissions: Contents = Read and write; Actions = Read and write.
4. Salin token. Jangan kirim token ke siapa pun dan jangan tempel di chat.

C. PASANG DASHBOARD DI INFINITYFREE
1. Upload index.php ke htdocs.
2. Upload config.example.php ke htdocs, lalu rename menjadi config.php.
3. Edit config.php: github_owner = username GitHub; github_repo = kizzxx-html-to-apk; github_branch = main; github_token = token yang dibuat.
4. Upload .htaccess juga. Pastikan config.php tidak bisa dibuka dari browser.
5. PHP harus mendukung cURL. Jika cURL tidak tersedia, panggilan GitHub API tidak bisa dilakukan.

D. CARA BUILD
1. Buka website InfinityFree.
2. Upload file .html atau .zip (maks 20 MB).
3. Isi nama aplikasi, package name, orientasi, warna.
4. Klik UPLOAD & BUILD APK.
5. Klik BUKA BUILD PROGRESS. Tunggu workflow selesai.
6. Jika hijau/success, buka run tersebut > Artifacts > Kizzxx-APK > Download. Ekstrak ZIP artifact untuk mendapatkan app-debug.apk.

BATASAN
- APK yang dibuat adalah debug APK untuk uji coba, bukan rilis Play Store.
- ZIP harus memiliki index.html di root atau dalam satu folder teratas. File HTML tunggal juga didukung.
- Build menggunakan Android WebView. Beberapa fitur browser (misalnya akses file lokal/permission tertentu, service worker, autoplay audio, push notification) bisa berbeda dari Chrome.
- Jangan upload project yang tidak kamu miliki atau tidak punya izin untuk dibungkus.
- Jika GitHub Actions belum berjalan, cek tab Actions dan pastikan Actions diaktifkan di repository.
- Jangan pernah membagikan Personal Access Token. Jika token bocor, revoke segera.
