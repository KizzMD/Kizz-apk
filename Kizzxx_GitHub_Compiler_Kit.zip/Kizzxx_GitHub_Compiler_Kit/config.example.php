<?php
// Salin menjadi config.php dan isi data repository GitHub milikmu.
return [
  'github_owner' => 'USERNAME_GITHUB',
  'github_repo' => 'kizzxx-html-to-apk',
  'github_branch' => 'main',
  'github_token' => 'ISI_FINE_GRAINED_TOKEN_DI_SINI',
];
